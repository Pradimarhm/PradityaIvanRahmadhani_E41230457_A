<nav class="navbar p-2">
    <span>Pengelolaan Nilai Workshop SI Web</span>
</nav>